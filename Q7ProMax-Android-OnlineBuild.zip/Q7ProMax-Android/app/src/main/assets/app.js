(() => {
"use strict";
const STORAGE_KEY = "q7-pro-max-v1";
const CONFIG = {model:"BOYUEDA Q7 Pro Max",voltage:52,capacityAh:28.8,fullVoltage:59.7,chargerA:3,motors:2,motorW:1600};
const CURVE = [[41.6,0],[44,10],[46,20],[47.6,30],[49,40],[50.4,50],[51.8,60],[53.2,70],[54.8,80],[56.5,90],[57.5,95],[59.7,100]];
const $ = id => document.getElementById(id);
let state = loadState();
function loadState(){try{const v=JSON.parse(localStorage.getItem(STORAGE_KEY)||"{}");return {readings:Array.isArray(v.readings)?v.readings:[],photo:typeof v.photo==="string"?v.photo:null};}catch{return {readings:[],photo:null};}}
function save(){try{localStorage.setItem(STORAGE_KEY,JSON.stringify(state));}catch(e){toast("Stockage insuffisant : exporte tes données et réduis la photo.");}}
function num(v){return Number(String(v).trim().replace(/\s/g,"").replace(",", "."));}
function fmt(v,d=1){return Number(v).toLocaleString("fr-FR",{minimumFractionDigits:d,maximumFractionDigits:d});}
function estimate(v){if(v<=CURVE[0][0])return 0;if(v>=CURVE[CURVE.length-1][0])return 100;for(let i=1;i<CURVE.length;i++){const [v2,p2]=CURVE[i],[v1,p1]=CURVE[i-1];if(v<=v2)return Math.round(p1+(v-v1)*(p2-p1)/(v2-v1));}return 100;}
function dateLabel(s){return new Date(s).toLocaleString("fr-FR",{day:"numeric",month:"long",year:"numeric",hour:"2-digit",minute:"2-digit"});}
function sorted(){return [...state.readings].sort((a,b)=>new Date(a.date)-new Date(b.date));}
function toast(s){const el=$("toast");el.textContent=s;el.classList.add("show");clearTimeout(toast.t);toast.t=setTimeout(()=>el.classList.remove("show"),2300);}
function escapeHTML(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function trips(){const r=sorted(),out=[];for(let i=1;i<r.length;i++){const a=r[i-1],b=r[i],dist=b.odo-a.odo;if(dist>0.0001){const recharge=b.percent>a.percent;out.push({date:b.date,dist,before:a,after:b,consumption:recharge?null:Math.max(0,a.percent-b.percent),recharge,anomaly:false});}}return out;}
function render(){
 const r=sorted(),last=r[r.length-1];
 $("lastVoltage").innerHTML=last?`${fmt(last.voltage)}<span class="unit"> V</span>`:'—<span class="unit"> V</span>';
 $("lastPercent").innerHTML=last?`${last.percent}<span class="unit"> %</span>`:'—<span class="unit"> %</span>';
 $("lastOdo").innerHTML=last?`${fmt(last.odo)}<span class="unit"> km</span>`:'—<span class="unit"> km</span>';
 $("readingCount").textContent=`${r.length} relevé${r.length>1?"s":""}`;$("historyCount").textContent=r.length;
 $("chartLatest").textContent=last?`${last.percent} %`:"—";
 renderCharge(last);renderChart(r);renderReadings(r);renderTrips();
 if(state.photo){$("scooterPhoto").src=state.photo;$("scooterPhoto").classList.remove("hidden");$("photoEmpty").classList.add("hidden");$("photoRemove").classList.remove("hidden");}
 else{$("scooterPhoto").classList.add("hidden");$("photoEmpty").classList.remove("hidden");$("photoRemove").classList.add("hidden");}
}
function renderCharge(last){const p=last?last.percent:0;$("chargeFrom").textContent=last?`Départ estimé : ${p} %`:"Aucun relevé : estimation depuis 0 %";[80,90,100].forEach(goal=>{const el=$("time"+goal);if(p>=goal){el.textContent="Atteint";return;}const ah=CONFIG.capacityAh*(goal-p)/100;const hours=ah/CONFIG.chargerA*1.25;el.textContent=formatDuration(hours*60);});}
function formatDuration(min){if(min<1)return "< 1 min";const rounded=Math.round(min/5)*5;const h=Math.floor(rounded/60),m=rounded%60;return h?`${h} h${m?` ${m} min`:""}`:`${m} min`;}
function renderChart(r){const canvas=$("batteryChart"),ctx=canvas.getContext("2d"),box=canvas.getBoundingClientRect(),dpr=window.devicePixelRatio||1;canvas.width=Math.max(1,Math.round(box.width*dpr));canvas.height=180*dpr;ctx.scale(dpr,dpr);ctx.clearRect(0,0,box.width,180);
 if(r.length<2){canvas.classList.add("hidden");$("chartEmpty").classList.remove("hidden");return;}canvas.classList.remove("hidden");$("chartEmpty").classList.add("hidden");
 const w=box.width,h=180,pad={l:28,r:12,t:14,b:25},cw=w-pad.l-pad.r,ch=h-pad.t-pad.b;
 ctx.font="10px -apple-system, sans-serif";ctx.fillStyle="#87958e";ctx.strokeStyle="rgba(77,105,91,.12)";ctx.lineWidth=1;
 [0,25,50,75,100].forEach(v=>{const y=pad.t+ch*(1-v/100);ctx.beginPath();ctx.moveTo(pad.l,y);ctx.lineTo(w-pad.r,y);ctx.stroke();ctx.fillText(v+"%",2,y+3);});
 const pts=r.map((x,i)=>({x:pad.l+(r.length===1?0:i/(r.length-1))*cw,y:pad.t+ch*(1-x.percent/100)}));
 ctx.beginPath();pts.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.strokeStyle="#45a978";ctx.lineWidth=2.8;ctx.lineJoin="round";ctx.lineCap="round";ctx.stroke();
 const g=ctx.createLinearGradient(0,pad.t,0,h-pad.b);g.addColorStop(0,"rgba(69,169,120,.18)");g.addColorStop(1,"rgba(69,169,120,0)");ctx.lineTo(pts[pts.length-1].x,h-pad.b);ctx.lineTo(pts[0].x,h-pad.b);ctx.closePath();ctx.fillStyle=g;ctx.fill();
 pts.forEach(p=>{ctx.beginPath();ctx.arc(p.x,p.y,3.3,0,Math.PI*2);ctx.fillStyle="#45a978";ctx.fill();ctx.strokeStyle="#fff";ctx.lineWidth=1.5;ctx.stroke();});
}
function renderReadings(r){const host=$("readingHistory");if(!r.length){host.innerHTML='<div class="empty">Aucun relevé pour le moment.</div>';return;}host.innerHTML=[...r].reverse().map(x=>`<div class="record"><div class="percent">${x.percent} %</div><div class="record-main"><strong>${fmt(x.voltage)} V · ${fmt(x.odo)} km</strong><small>${dateLabel(x.date)}</small></div><button class="delete" data-delete="${x.id}" aria-label="Supprimer le relevé">×</button></div>`).join("");host.querySelectorAll("[data-delete]").forEach(b=>b.addEventListener("click",()=>{if(confirm("Supprimer ce relevé ? Les sorties seront recalculées.")){state.readings=state.readings.filter(x=>x.id!==b.dataset.delete);save();render();toast("Relevé supprimé");}}));}
function renderTrips(){const t=trips();$("tripCount").textContent=t.length;$("tripAverage").innerHTML=t.length?`${fmt(t.reduce((s,x)=>s+x.dist,0)/t.length)} <span class="unit">km</span>`:'— <span class="unit">km</span>';
 const host=$("tripHistory");if(!t.length){host.innerHTML='<div class="empty">Tes sorties calculées apparaîtront ici après deux relevés avec un odomètre croissant.</div>';return;}
 host.innerHTML=[...t].reverse().map(x=>`<div class="trip"><div class="triptop"><strong>${fmt(x.dist)} km</strong><span>${dateLabel(x.date)}</span></div><p>${x.recharge?'Recharge détectée — consommation non calculable':`${x.consumption} % utilisés`}<br>Odomètre : ${fmt(x.before.odo)} → ${fmt(x.after.odo)} km<br>Batterie : ${x.before.percent} → ${x.after.percent} %</p></div>`).join("");}
function openModal(id){$(id).classList.add("show");}function closeModal(id){$(id).classList.remove("show");}
$("addReading").addEventListener("click",()=>{const r=sorted();$("voltageInput").value="";$("odoInput").value=r.length?String(r[r.length-1].odo).replace(".",","):"";$("dateInput").value=new Date(Date.now()-new Date().getTimezoneOffset()*60000).toISOString().slice(0,16);openModal("readingModal");});
$("cancelReading").addEventListener("click",()=>closeModal("readingModal"));
$("readingForm").addEventListener("submit",e=>{e.preventDefault();const voltage=num($("voltageInput").value),odo=num($("odoInput").value),date=new Date($("dateInput").value);if(!Number.isFinite(voltage)||voltage<20||voltage>80){toast("Vérifie la tension saisie.");return;}if(!Number.isFinite(odo)||odo<0){toast("Vérifie l'odomètre.");return;}if(Number.isNaN(date.getTime())){toast("Vérifie la date.");return;}const existing=state.readings.find(x=>x.date===date.toISOString());if(existing){toast("Un relevé existe déjà à cette date.");return;}const prev=sorted().slice(-1)[0];if(prev&&odo<prev.odo&&!confirm("L'odomètre est inférieur au relevé précédent. Cela peut indiquer une remise à zéro. Enregistrer quand même ?"))return;state.readings.push({id:crypto.randomUUID?crypto.randomUUID():String(Date.now())+Math.random(),date:date.toISOString(),voltage,odo,percent:estimate(voltage)});save();closeModal("readingModal");render();toast("Relevé enregistré");});
document.querySelectorAll(".tab").forEach(b=>b.addEventListener("click",()=>{document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x===b));document.querySelectorAll(".page").forEach(x=>x.classList.toggle("active",x.id===b.dataset.page));window.scrollTo({top:0,behavior:"smooth"});}));
$("settingsBtn").addEventListener("click",()=>openModal("settingsModal"));$("closeSettings").addEventListener("click",()=>closeModal("settingsModal"));
$("photoAdd").addEventListener("click",()=>$("photoInput").click());$("photoInput").addEventListener("change",e=>{const file=e.target.files[0];if(!file)return;if(file.size>4*1024*1024){toast("Photo trop lourde (maximum 4 Mo).");return;}const reader=new FileReader();reader.onload=()=>{const im=new Image();im.onload=()=>{const c=document.createElement("canvas"),scale=Math.min(1,1200/Math.max(im.width,im.height));c.width=im.width*scale;c.height=im.height*scale;c.getContext("2d").drawImage(im,0,0,c.width,c.height);state.photo=c.toDataURL("image/jpeg",.78);save();render();toast("Photo enregistrée");};im.src=reader.result;};reader.readAsDataURL(file);e.target.value="";});
$("photoRemove").addEventListener("click",()=>{if(confirm("Supprimer la photo ?")){state.photo=null;save();render();}});
$("exportBtn").addEventListener("click",()=>{const json=JSON.stringify({app:"Q7 Pro Max",version:1,exportedAt:new Date().toISOString(),config:CONFIG,readings:state.readings,photo:state.photo},null,2);if(window.AndroidBridge&&window.AndroidBridge.saveBackup){window.AndroidBridge.saveBackup(json);toast("Choisis où enregistrer la sauvegarde");return;}const blob=new Blob([json],{type:"application/json"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="q7-pro-max-sauvegarde.json";a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);toast("Sauvegarde exportée");});
$("importBtn").addEventListener("click",()=>$("importInput").click());$("importInput").addEventListener("change",e=>{const f=e.target.files[0];if(!f)return;const rd=new FileReader();rd.onload=()=>{try{const data=JSON.parse(rd.result);if(!data||!Array.isArray(data.readings))throw Error();const valid=data.readings.every(x=>x&&typeof x.date==="string"&&Number.isFinite(Date.parse(x.date))&&Number.isFinite(Number(x.voltage))&&Number(x.voltage)>0&&Number.isFinite(Number(x.odo))&&Number(x.odo)>=0);if(!valid)throw Error();if(!confirm("Remplacer toutes les données actuelles par cette sauvegarde ?"))return;state.readings=data.readings.map(x=>({id:String(x.id||Date.now()+Math.random()),date:new Date(x.date).toISOString(),voltage:Number(x.voltage),odo:Number(x.odo),percent:estimate(Number(x.voltage))}));state.photo=typeof data.photo==="string"&&data.photo.startsWith("data:image/")?data.photo:null;save();render();closeModal("settingsModal");toast("Sauvegarde importée");}catch{alert("Fichier invalide ou format non reconnu.");}finally{e.target.value="";}};rd.readAsText(f);});
$("clearBtn").addEventListener("click",()=>{if(confirm("Effacer définitivement les relevés et la photo enregistrés sur cet appareil ? Pense à exporter une sauvegarde avant.")){state={readings:[],photo:null};save();render();closeModal("settingsModal");toast("Données locales effacées");}});
window.addEventListener("resize",()=>{if($("dashboard").classList.contains("active"))renderChart(sorted());});
if("serviceWorker" in navigator && location.protocol!=="file:"){window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));}
render();
})();