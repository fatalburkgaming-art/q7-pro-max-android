Q7 PRO MAX — PROJET ANDROID

Ce dossier est un projet Android Studio qui embarque l'application localement dans une WebView.
Il ne dépend pas de Cloudflare, d'un serveur, du GPS ou du Bluetooth.

POUR GÉNÉRER L'APK :
1. Sur un ordinateur, installe Android Studio (version récente).
2. Décompresse Q7ProMax-Android.zip.
3. Dans Android Studio, choisis Open et sélectionne le dossier Q7ProMax-Android.
4. Laisse Gradle télécharger les composants Android demandés (connexion Internet nécessaire à cette étape).
5. Menu Build > Build Bundle(s) / APK(s) > Build APK(s).
6. L'APK de test sera dans app/build/outputs/apk/debug/app-debug.apk.
7. Transfère ce fichier sur ton Android, ouvre-le et autorise temporairement l'installation depuis cette source si Android le demande.

Pour une version partageable durablement, crée ensuite un APK signé via Build > Generate Signed Bundle / APK.

DONNÉES :
- Les relevés sont stockés dans le stockage local de l'application.
- L'importation de fichiers JSON est prise en charge.
- L'export utilise la boîte de dialogue Android « Enregistrer sous ».
- Désinstaller l'application peut supprimer les données locales : exporte régulièrement une sauvegarde.

NOTE :
Je ne peux pas compiler un APK binaire dans cet environnement : Android SDK, Gradle et les outils de signature ne sont pas installés ici. Ce ZIP contient le projet Android Studio prêt à compiler, pas un APK déjà compilé.
